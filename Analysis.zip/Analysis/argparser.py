import argparse
import sys
import os

parser = argparse.ArgumentParser()

parser.add_argument('--inputfile')
parser.add_argument('--analyser')



args = parser.parse_args()

if len(sys.argv) < 5:
	print "Incorrect Syntax. \nUsage: python argparser.py --inputfile <filename> --analyser <analyser-name>"
	#print parser.print_usage()
	print "List of available analysers is:"
	print "1. dbscan \n2. hac \n3. local-outlier \n4. elliptic \n5. knn\n6. meanshift\n7. centroid-median-hac\n8. single-complete-hac\n9. ward-avg-hac"
	print "10. response_size-kmeans\n11. response_status-kmeans\n12. response_code\n13. peak_hour\n14. verb-kproto"
	print "15. url-kproto\n16. hourly-req-host\n17. hourly-requests\n18. num_param_ip"
	print "19. ip_url_param\n20. url_one_time_hit\n21. hosts_unique_url_hits\n22. missing_extra_params\n23.default"
    #sys.exit(2)
elif sys.argv[1] != "--inputfile":
    print "Invalid switch '"+sys.argv[1]+"'"
    sys.exit(2)
elif os.path.isfile(args.inputfile) == False:
    print "File does not exist"
    sys.exit(2)
elif sys.argv[3] != "--analyser":
	print "Invalid switch '"+sys.argv[3]+"'"
	sys.exit(2)


elif args.analyser == "dbscan":
	print "Running DBSCAN!"
	#os.system("analysis-4-dendogram-hac.py "+args.inputfile)
	os.system('python analysis-4-dbscan.py '+args.inputfile)
	#run dbscan only

elif args.analyser == "hac":
	print "Running dendogram-hac"
	os.system('python analysis-4-dendogram-hac.py '+args.inputfile)


elif args.analyser == "local-outlier":
	print "Running local-outlier"
	os.system('python analysis-4-LOF.py '+args.inputfile)


elif args.analyser == "elliptic":
	print "Running elliptic"
	os.system('python analysis-4-elliptic.py '+args.inputfile)

elif args.analyser == "knn":
	print "Running knn"
	os.system('python analysis-4-knn.py '+args.inputfile)

elif args.analyser == "meanshift":
	print "Running meanshift"
	os.system('python analysis-4-meanshift.py '+args.inputfile)



elif args.analyser == "centroid-median-hac":
	print "Running centroid-median-hac"
	os.system('python analysis-4-centroid-median.py '+args.inputfile)

elif args.analyser == "single-complete-hac":
	print "Running single-complete-hac"
	os.system('python analysis-4-single-complete.py '+args.inputfile)

elif args.analyser == "ward-avg-hac":
	print "Running ward-avg-hac"
	os.system('python analysis-4-ward-avg.py '+args.inputfile)

elif args.analyser == "response_size-kmeans":
	print "Running response_size-kmeans"
	os.system('python analysis-4.py '+args.inputfile)

elif args.analyser == "response_status-kmeans":
	print "Running response_status-kmeans"
	os.system('python analysis-1.py '+args.inputfile)

elif args.analyser == "response_code":
	print "Running response_code"
	os.system('python analysis-2.py '+args.inputfile)

elif args.analyser == "peak_hour":
	print "Running peak_hour"
	os.system('python analysis-3.py '+args.inputfile)


elif args.analyser == "verb-kproto":
	print "Running verb-kproto"
	os.system('python analysis-5.py '+args.inputfile)

elif args.analyser == "url-kproto":
	print "Running url-kproto"
	os.system('python analysis-6.py '+args.inputfile)

elif args.analyser == "hourly-req-host":
	print "Running hourly-req-host"
	os.system('python analysis-7.py '+args.inputfile)

elif args.analyser == "hourly-requests":
	print "Running hourly-requests"
	os.system('python analysis-8.py '+args.inputfile)

elif args.analyser == "num_param_ip":
	print "Running num_param_ip"
	os.system('python analysis-9.py '+args.inputfile)

elif args.analyser == "ip_url_param":
	print "Running ip_url_param"
	os.system('python analysis-10.py '+args.inputfile)

elif args.analyser == "url_one_time_hit":
	print "Running url_one_time_hit"
	os.system('python analysis-11.py '+args.inputfile)

elif args.analyser == "hosts_unique_url_hits":
	print "Running hosts_unique_url_hits"
	os.system('python analysis-12.py '+args.inputfile)

elif args.analyser == "missing_extra_params":
	print "Running missing_extra_params"
	os.system('python analysis-13.py '+args.inputfile)



	#run k-proto

elif args.analyser == "default":
	print "Running default: hosts_unique_url_hits"
	os.system('python analysis-12.py '+args.inputfile)
	#run default

else:
	print "Invalid choice of analyser!"
	print "Please choose from:\n1. dbscan \n2. hac \n3. local-outlier \n4. elliptic \n5. knn\n6. meanshift\n7. centroid-median-hac\n8. single-complete-hac\n9. ward-avg-hac"
	print "10. response_size-kmeans\n11. response_status-kmeans\n12. response_code\n13. peak_hour\n14. verb-kproto"
	print "15. url-kproto\n16. hourly-req-host\n17. hourly-requests\n18. num_param_ip"
	print "19. ip_url_param\n20. url_one_time_hit\n21. hosts_unique_url_hits\n22. missing_extra_params\n23. default"
	sys.exit(2)







